https://github.com/gin-gonic/autotls //calisan 

https://medium.com/@erinus/go-my-way-day-2-344b47e270b9  best 

https://go-acme.github.io/lego/

https://gist.github.com/erangaeb/23c33d6529ee499ad34ebe6e54c17978#file-nginx-conf

https://stackoverflow.com/questions/69829587/nginx-proxy-https-to-http-routinesssl3-get-recordwrong-version-number

https://gist.github.com/CeeFeS/e909d31a50576f0fc67dd5a2d62ec992

https://marcofranssen.nl/build-a-go-webserver-on-http-2-using-letsencrypt